<?php
define('_JEXEC', 1);
define('JPATH_BASE', dirname(__DIR__)); 
if (!file_exists(JPATH_BASE . '/configuration.php')) {
    die('Файл configuration.php не найден по адресу: ' . JPATH_BASE);
}
require_once JPATH_BASE . '/configuration.php';
$config = new JConfig();
$dbHost = $config->host;
$dbPort = 3306;
if (strpos($dbHost, ':') !== false) {
    list($dbHost, $dbPort) = explode(':', $dbHost, 2);
}
try {
    $dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$config->db};charset=utf8mb4";
    $pdo = new PDO($dsn, $config->user, $config->password, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("Ошибка подключения к БД: " . $e->getMessage());
}
$prefix = $config->dbprefix;
$targetDate = '2026-06-01 00:00:00';

try {
    $stmt = $pdo->prepare("SELECT id, username FROM `{$prefix}users` WHERE `registerDate` >= ?");
    $stmt->execute([$targetDate]);
    $users = $stmt->fetchAll();

    if (empty($users)) {
        echo "Пользователи, зарегистрированные после 01.06.2026, не найдены.<br>";
    } else {
        echo "Найдено пользователей для удаления: " . count($users) . "<br><br>";
        $delUsers   = $pdo->prepare("DELETE FROM `{$prefix}users` WHERE `id` = ?");
        $delMap     = $pdo->prepare("DELETE FROM `{$prefix}user_usergroup_map` WHERE `user_id` = ?");
        $delProfile = $pdo->prepare("DELETE FROM `{$prefix}user_profiles` WHERE `user_id` = ?");

        foreach ($users as $user) {
            $id = $user['id'];
            $username = $user['username'];
            if ($username == 'admin') continue;
            $delUsers->execute([$id]);
            $delMap->execute([$id]);
            $delProfile->execute([$id]);

            echo "Пользователь <b>{$username}</b> (ID: {$id}) успешно стерт из БД.<br>";
        }
    }
} catch (Exception $e) {
    echo "Ошибка при выполнении SQL: " . $e->getMessage();
}
if (@unlink(__FILE__)) {
    echo "<br><b>Безопасность:</b> Файл скрипта автоматической очистки удален с сервера.";
}
